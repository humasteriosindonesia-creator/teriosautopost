package id.terios.autopost

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

data class QueueItem(val name: String, val status: String = "Menunggu")

class MainViewModel : androidx.lifecycle.ViewModel() {
    var items by mutableStateOf(listOf<QueueItem>())
        private set
    var delaySeconds by mutableStateOf(10)
        private set

    fun setDelay(value: Int) { delaySeconds = value.coerceAtLeast(10) }

    fun addDemoItems() {
        items = items + List(5) { QueueItem("Foto ${items.size + it + 1}.jpg") }
    }

    fun start() {
        if (items.isEmpty()) return
        items = items.mapIndexed { i, x ->
            if (i == 0) x.copy(status = "Siap dikirim") else x
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: MainViewModel = viewModel()
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(
                        Modifier.fillMaxSize().padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text("Terios Auto Post", style = MaterialTheme.typography.headlineMedium)
                        Text("Satu akun Instagram • Antrean foto")

                        Button(onClick = { vm.addDemoItems() }, modifier = Modifier.fillMaxWidth()) {
                            Text("＋ Tambah Foto (demo)")
                        }

                        OutlinedTextField(
                            value = "#teriosid #daihatsuofficialclub #daihatsutidoktober",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Hashtag") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Button(
                            onClick = { vm.start() },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = vm.items.isNotEmpty()
                        ) { Text("Mulai Antrean") }

                        Text("Jeda antar-posting: ${vm.delaySeconds} detik")

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(10, 30, 60, 300).forEach { seconds ->
                                OutlinedButton(onClick = { vm.setDelay(seconds) }) {
                                    Text(if (seconds < 60) "${seconds}s" else "${seconds / 60}m")
                                }
                            }
                        }

                        Text("Antrean: ${vm.items.size} foto")
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            itemsIndexed(vm.items) { index, item ->
                                Card(Modifier.fillMaxWidth()) {
                                    Row(
                                        Modifier.padding(14.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("${index + 1}. ${item.name}")
                                        Text(item.status)
                                    }
                                }
                            }
                        }

                        Text(
                            "Catatan: modul posting Instagram resmi belum diaktifkan. " +
                            "Akun harus Instagram Professional dan aplikasi perlu OAuth/Meta App."
                        )
                    }
                }
            }
        }
    }
}
