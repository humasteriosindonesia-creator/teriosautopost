# Terios Auto Post

Starter Android app untuk satu akun Instagram.

## Fitur MVP
- Jeda default antar-posting: **10 detik** (pilihan 10 detik, 30 detik, 1 menit, 5 menit)
- Antrean banyak foto
- Status antrean
- Template hashtag Terios
- Tombol mulai antrean

## Tahap integrasi Instagram resmi
Gunakan Instagram API with Instagram Login dari Meta.
Akun Instagram harus Professional (Business/Creator).
Permission publishing saat ini menggunakan `instagram_business_content_publish`.
Media untuk publishing harus dapat diakses oleh API melalui URL publik.

Jangan menaruh App Secret di aplikasi Android. Untuk produksi, token dan proses yang membutuhkan secret harus ditempatkan pada backend yang aman.

Dokumentasi resmi Meta:
https://developers.facebook.com/docs/instagram-platform/instagram-api-with-instagram-login/
